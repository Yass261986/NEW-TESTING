"use strict";
! function() {
    let t = !0;
    t && (window["C3_ModernJSSupport_OK"] = !0)
}();